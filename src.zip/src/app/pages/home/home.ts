import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

import { IonContent } from '@ionic/angular/ion-content';
import { IonButton } from '@ionic/angular/ion-button';
import { IonIcon } from '@ionic/angular/ion-icon';
import { IonCard } from '@ionic/angular/ion-card';
import { IonCardContent } from '@ionic/angular/ion-card-content';
import { IonGrid } from '@ionic/angular/ion-grid';
import { IonRow } from '@ionic/angular/ion-row';
import { IonCol } from '@ionic/angular/ion-col';

@Component({
  selector: 'app-home',
  imports: [
    RouterModule,
    IonContent,
    IonButton,
    IonIcon,
    IonCard,
    IonCardContent,
    IonGrid,
    IonRow,
    IonCol
  ],
  templateUrl: './home.html',
  styleUrl: './home.scss'
})
export class Home {}